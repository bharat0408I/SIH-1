export const scholarships = [
  { id: 's1', name: 'National Scholarship Portal', type: 'Government', url: 'https://scholarships.gov.in/' },
  { id: 's2', name: 'OpenStax Textbooks', type: 'Open e-books', url: 'https://openstax.org/' },
  { id: 's3', name: 'NPTEL Courses', type: 'Study Material', url: 'https://nptel.ac.in/' },
]
