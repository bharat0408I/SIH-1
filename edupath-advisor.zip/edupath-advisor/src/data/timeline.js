export const timelineItems = [
  { id: 't1', date: '2025-10-01', title: 'University A Admissions Open', type: 'admission' },
  { id: 't2', date: '2025-11-15', title: 'Scholarship X Application Deadline', type: 'scholarship' },
  { id: 't3', date: '2026-01-10', title: 'Entrance Exam Y Registration Starts', type: 'exam' },
]
